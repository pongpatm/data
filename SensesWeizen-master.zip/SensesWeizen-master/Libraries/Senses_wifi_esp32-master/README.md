# Senses_wifi_esp32
A library for send data from Internet of Things to "Senses IoT platform" compatible with ESP32 wifi chip series
